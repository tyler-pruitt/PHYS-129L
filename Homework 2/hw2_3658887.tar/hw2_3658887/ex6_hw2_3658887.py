#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 13:48:54 2020

@author: tylerpruitt
"""


text = input('Enter text: ')

print('a:',text.count('a')+text.count('A'))
print('b:',text.count('b')+text.count('B'))
print('c:',text.count('c')+text.count('C'))
print('d:',text.count('d')+text.count('D'))
print('e:',text.count('e')+text.count('E'))
print('f:',text.count('f')+text.count('F'))
print('g:',text.count('g')+text.count('G'))
print('h:',text.count('h')+text.count('H'))
print('i:',text.count('i')+text.count('I'))
print('j:',text.count('j')+text.count('J'))
print('k:',text.count('k')+text.count('K'))
print('l:',text.count('l')+text.count('L'))
print('m:',text.count('m')+text.count('M'))
print('n:',text.count('n')+text.count('N'))
print('o:',text.count('o')+text.count('O'))
print('p:',text.count('p')+text.count('P'))
print('q:',text.count('q')+text.count('Q'))
print('r:',text.count('r')+text.count('R'))
print('s:',text.count('s')+text.count('S'))
print('t:',text.count('t')+text.count('T'))
print('u:',text.count('u')+text.count('U'))
print('v:',text.count('v')+text.count('V'))
print('w:',text.count('w')+text.count('W'))
print('x:',text.count('x')+text.count('X'))
print('y:',text.count('y')+text.count('Y'))
print('z:',text.count('z')+text.count('Z'))
print("' ':",text.count(' '))
print('characters:', len(text))
